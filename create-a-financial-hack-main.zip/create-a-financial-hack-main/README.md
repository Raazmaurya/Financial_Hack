# create-a-financial-hack
MLH Local Hack Day: Build 2021 Week-Long Challenge: Create a Financial Hack

## Task Statement
Whether you’re tackling budgeting for college students or financial modeling for stock markets, we want to see you create something inspired by finance. This can be as simple as looking at data from one or two stocks, or as complex as a holistic view of someone’s finances. Submit your hack on our Week-Long Devpost!

# Submission
## Cryptocurrency Price Tracker
The way this works is, given the price you bought a certain crypto at, if the value of the currency goes above the price you bought it at, the script plays "You Suffer" by Napalm Death at full volume over your speakers.

Inspired by Bertram Gilfoyle from Silicon Valley

[![IMAGE ALT TEXT HERE](http://img.youtube.com/vi/uS1KcjkWdoU/0.jpg)](http://www.youtube.com/watch?v=uS1KcjkWdoU)
